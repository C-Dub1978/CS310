/*
 * This program will read a list of realtor and/or property data from a csv file, and try to create 
 * realtor and property objects with said data. It will help a real estate office in converting data from the csv
 * files into useful information
 */
package cs310wilson;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/** Main Class, reads the data from the specified file and builds objects with the data
 * 
 * @author Chris Wilson
 * @version x Java Assn 1
 */
public class CS310Wilson {
    /** main method
     *   tries to open the file and the scanner, reads the data line by line, and calls on both realtor or property
     *   constructors to attempt to build the corresponding objects, then verifies the data fields
     * @param args, the command line arguments
     */
    public static void main(String[] args) {
        final String INPUT_FILENAME = "input/assn1input1.txt";        
        File inputFile = null;
        Scanner inputScanner = null;

        // Test set 1
        // 1A
        System.out.println("Running test 1A:");
        Realtor realtor1 = new Realtor("CO1234567", "Chris",
                "Wilson", "206-999-9044", 55000);
        String realtor1Str = realtor1.toString();
        System.out.println(realtor1Str);
        System.out.println();

        // 1B
        System.out.println("Running test 1B:");
        Property property1 = new Property(7654321, "CO1234567",
                "312 Granville Ave", "Firestone", "CO",
                80520, 3, 2.5, false,
                240000);
        System.out.println(property1.toString());
        System.out.println();

        // Test set 2
        // 2A
        System.out.println("Running test 2A:");
        try {
            inputFile = new File(INPUT_FILENAME);
            inputScanner = new Scanner(inputFile);
        } catch(FileNotFoundException e) {
            System.err.println("Error opening file " + inputFile);
            System.exit(1);
        }        
        
        Realtor realtor2 = new Realtor();
        String[] firstLine = inputScanner.nextLine().split(",");               
        if(firstLine[0].equals("REALTOR")) {
            realtor2 = setRealtorAttributes(realtor2, firstLine);
            boolean validLicense = realtor2.checkRealtorLicense();
            boolean validPhoneNum = realtor2.checkPhoneNumber();
            if(!validLicense) {
                System.out.println("Error, license is invalid");
            }
            if(!validPhoneNum) {
                System.out.println("Error, invalid phone number");
            }
            displayRealtorAttributes(realtor2);
        } else {
            System.out.println("Error, data is not realtor data");
        }
        System.out.println("Done with test 2A");
        System.out.println();        

        // 2B
        System.out.println("Running test 2B:");
        Realtor realtor3 = new Realtor();
        String[] secondLine = inputScanner.nextLine().split(",");            
        if(secondLine[0].equals("REALTOR")) {
            realtor3 = setRealtorAttributes(realtor3, secondLine);
            boolean validLicense = realtor3.checkRealtorLicense();
            boolean validPhoneNum = realtor3.checkPhoneNumber();
            if(!validLicense) {
                System.out.println("Error, license is invalid");
            }
            if(!validPhoneNum) {
                System.out.println("Error, invalid phone number");
            }
            displayRealtorAttributes(realtor3);
        } else {
            System.out.println("Error, data is not realtor data");
        }
        System.out.println("Done with 2B");
        System.out.println();

        // 2C
        System.out.println("Running test 2C:");
        Property property2 = new Property();
        String[] thirdLine = inputScanner.nextLine().split(",");
        if(thirdLine[0].equals("PROPERTY")) {
            property2 = setPropertyAttributes(property2, thirdLine);
            boolean validMls = property2.checkMlsNum();
            boolean validState = property2.checkState();
            boolean validZip = property2.checkZipCode();
            if(!validMls) {
                System.out.println("Error, mls is invalid");
            }
            if(!validState) {
                System.out.println("Error, invalid state");
            }
            if(!validZip) {
                System.out.println("Error, invalid zip code");
            }
            displayPropertyAttributes(property2);
        } else {
            System.out.println("Error, data is not property data");
        }
        System.out.println();

        // 2D
        System.out.println("Running test 2D:");
        Property property3 = new Property();
        String[] fourthLine = inputScanner.nextLine().split(",");
        if(fourthLine[0].equals("PROPERTY")) {
            property3 = setPropertyAttributes(property3, fourthLine);
            boolean validMls = property3.checkMlsNum();
            boolean validState = property3.checkState();
            boolean validZip = property3.checkZipCode();
            if(!validMls) {
                System.out.println("Error, mls is invalid");
            }
            if(!validState) {
                System.out.println("Error, invalid state");
            }
            if(!validZip) {
                System.out.println("Error, invalid zip code");
            }
            displayPropertyAttributes(property3);
        } else {
            System.out.println("Error, data is not property data");
        }
        System.out.println();
        inputScanner.close();
        inputFile = null;

        // Test set 3
        // 3A
        System.out.println("Running test 3A:");
        String status = realtor2.equals(realtor3) ? " " : " not ";
        System.out.println("Realtor2 object is" + status + "equal to realtor3 object!");        
        System.out.println();
        // 3B
        System.out.println("Running test 3B:");
        status = property2.equals(property3) ? " " : " not ";
        System.out.println("Property2 object is" + status + "equal to property3 object!");        
        System.out.println();
    }

    /** Method to mutate Realtor object data fields
     *
     * @param realtor, the Realtor object to be mutated and returned
     * @param attrbs, array with all the different data field attributes to be set
     * @return realtor, the mutated Realtor object
     */
    public static Realtor setRealtorAttributes(Realtor realtor,
                                               String[] attrbs) {
        realtor.setLicenseNum(attrbs[2]);
        realtor.setFirstName(attrbs[3]);
        realtor.setLastName(attrbs[4]);
        realtor.setPhoneNum(attrbs[5]);
        realtor.setCommission(Double.parseDouble(attrbs[6]));
        System.out.println(realtor.toString());
        return realtor;
    }

    /** Method to mutate Property object data fields
     *
     * @param property, the Property object to be mutated and returned
     * @param attrbs, array with all the different data field attributes to be set
     * @return property, the mutated Property object
     */
    public static Property setPropertyAttributes(Property property,
                                                 String[] attrbs) {        
        property.setMls(Integer.parseInt(attrbs[2]));        
        property.setRealtorLicenseNum(attrbs[3]);
        property.setStreetAddress(attrbs[4]);
        property.setCity(attrbs[5]);
        property.setState(attrbs[6]);
        property.setZip(Integer.parseInt(attrbs[7]));
        property.setNumBedrooms(Integer.parseInt(attrbs[8]));
        property.setNumBathrooms(Double.parseDouble(attrbs[9]));
        if(attrbs[10].equals("Y")) {
            property.setSold(true);
        } else {
            property.setSold(false);
        }
        property.setAskingPrice(Double.parseDouble(attrbs[11]));
        return property;
    }

    /** Method to display the Realtor object attributes in a visually pleasing manner
     *
     * @param realtor, the Realtor object to display
     */
    public static void displayRealtorAttributes(Realtor realtor) {
        System.out.println("Realtor license: " + realtor.getLicenseNum());
        System.out.println("Realtor first name: " + realtor.getFirstName());
        System.out.println("Realtor last name: " + realtor.getLastName());
        System.out.println("Realtor phone number: " + realtor.getPhoneNum());
        System.out.println("Realtor commission: " + realtor.getCommission());
    }

    /** Method to display the Property object attributes in a visually pleasing manner
     *
     * @param property, the Property object to display 
     */
    public static void displayPropertyAttributes(Property property) {
        System.out.println("Property mls: " + property.getMls());
        System.out.println("Property realtor license number: "
            + property.getRealtorLicenseNum());
        System.out.println("Property street address: "
                + property.getStreetAddress());
        System.out.println("Property city: " + property.getCity());
        System.out.println("Property state: " + property.getState());
        System.out.println("Property zip code: " + property.getZip());
        System.out.println("Property number of bedrooms: "
            + property.getNumBedrooms());
        System.out.println("Property number of bathrooms: "
            + property.getNumBathrooms());
        System.out.println("Is property sold? " + property.isSold());
        System.out.println("Property asking price: "
            + property.getAskingPrice());
    }
}
