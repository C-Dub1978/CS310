/*
 * Realtor Node class for linked list implementation
 */
package cs310wilson;

import java.util.Objects;

/** Realtor node class, with next reference and realtor object as fields
 *
 * @author Chris Wilson
 * @version java assn 3
 */
public class RealtorNode {
    private RealtorNode nextNode;
    private Realtor realtor;
    
    /** Constructor
     *
     * @param r, realtor object
     */
    public RealtorNode(Realtor r) {
        realtor = r;
        nextNode = null;
    }
    
    /** 2 parameter constructor
     *
     * @param r, the realtor object
     * @param next, the RealtorNode object
     */
    public RealtorNode(Realtor r, RealtorNode next) {
        realtor = r;
        nextNode = next;
    }
    
    /** Default constructor
     *
     */
    public RealtorNode() {
        realtor = null;
        nextNode = null;
    }
    
    /** Getter, for the realtor object field
     *
     * @return realtor, the data field
     */
    public Realtor getRealtor() {
        return realtor;
    }
    
    /** Setter, realtor object field
     *
     * @param r, realtor object to set
     */
    public void setRealtor(Realtor r) {
        realtor = r;
    }
    
    /** Method to get the next RealtorNodereference
     *
     * @return nextNode, the next node
     */
    public RealtorNode getNext() {
        return nextNode;
    }
    
    /** Setter, to set next node
     *
     * @param r, the RealtorNode object
     */
    public void setNext(RealtorNode r) {
        nextNode = r;
    }
    
    /** Overriden toString method for display
     * 
     * @return string value of realtor
     */
    @Override
    public String toString() {
        return "Realtor: " + realtor.getLastName() + ", " + 
               realtor.getFirstName() + "\n\t" + "License: " + 
               realtor.getLicenseNum();        
    }    
    
    /** Overriden equals method
     * 
     * @param obj, a RealtorNode object to compare to "this"
     * @return boolean value of equality
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final RealtorNode other = (RealtorNode) obj;
        if (!Objects.equals(this.nextNode, other.nextNode)) {
            return false;
        }
        if (!Objects.equals(this.realtor, other.realtor)) {
            return false;
        }
        return true;
    }
    
    
}
