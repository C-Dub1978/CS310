/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs310wilson;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author klown
 */
public class RealtorLogImplTest {
    RealtorLogImpl array;
    
    public RealtorLogImplTest() {
    }
    
    @Before
    public void setUp() {
        
    }

    /**
     * Test of getRealtorLog method, of class RealtorLogImpl.
     */
    @Test
    public void testGetRealtorLog() {
    }

    /**
     * Test of add method, of class RealtorLogImpl.
     */
    @Test
    public void testAdd() {
    }

    /**
     * Test of remove method, of class RealtorLogImpl.
     */
    @Test
    public void testRemove() {
    }

    /**
     * Test of isLicenseUnique method, of class RealtorLogImpl.
     */
    @Test
    public void testIsLicenseUnique() {
    }
    
}
