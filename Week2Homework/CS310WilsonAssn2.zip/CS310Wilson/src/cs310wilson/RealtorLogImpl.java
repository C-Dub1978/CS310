/*
 * Class for keeping track of the ArrayList of realtors and it's associated
 * functionality
 */
package cs310wilson;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Realtor log class
 * @author Chris Wilson
 * @version java assn 2
 */
public class RealtorLogImpl {
    private ArrayList<Realtor> realtorLog;
    
    /**
     * Default constructor
     */
    public RealtorLogImpl() {
        realtorLog = new ArrayList<>();
    }
    
    /**
     * Getter, for the realtor ArrayList
     * @return the data field
     */
    public ArrayList<Realtor> getRealtorLog() {
        return realtorLog;
    }
    
    /**
     * Method to add realtor to list
     * @param obj, the realtor to add
     */
    public void add(Realtor obj) {
        realtorLog.add(obj);
        Collections.sort(realtorLog);
    }
    
    /**
     * Method to remove a realtor
     * @param license, the realtor license 
     * @return boolean value of success/failure
     */
    public boolean remove(String license) {
        int count = 0;
        for(Realtor r : realtorLog) {
            if(r.getLicenseNum().equals(license)) {
                realtorLog.remove(count);
                return true;
            }
            count++;
        }
        return false;
    }
    
    /**
     * Method to check if a realtor license is in the list
     * @param license, realtor license to check for
     * @return boolean value of success/failure
     */
    public boolean isLicenseUnique(String license) {
        if(realtorLog.isEmpty()) {
            return true;
        }        
        for(Realtor r: realtorLog) {
            if(license.equals(r.getLicenseNum())) {
                return false;
            }
        }        
        return true;
    }
    
    /**
     * Overridden toString method
     * @return String value of class
     */
    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        int count = 0;
        for(Realtor r : realtorLog) {
            str.append(r.getLicenseNum());
            str.append(" - index ");
            str.append(count);
            str.append("\n");
            count++;
        }
        return str.toString();
    }
    
    
    
}
